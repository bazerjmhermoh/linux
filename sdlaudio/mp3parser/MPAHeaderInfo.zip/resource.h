//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MPEGAudioInfo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDS_ABOUTBOX                    101
#define IDD_MPEGAUDIOINFO_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDD_ABOUTBOX                    129
#define IDC_OPENFILE                    1000
#define IDC_OUTPUT                      1001
#define IDC_FILE                        1002
#define IDC_INFO1                       1003
#define IDC_INFO2                       1004
#define IDC_TAGINFO                     1005
#define IDC_CHECKFILE                   1006
#define IDC_VBRINFO                     1007
#define IDC_PREVFRAME                   1008
#define IDC_NEXTFRAME                   1009
#define IDC_FRAMENO                     1010
#define IDC_FIRSTFRAME                  1011
#define IDC_LASTFRAME                   1012
#define IDC_FILEINFO                    1014
#define IDC_BUTTON1                     1015
#define IDC_ABOUT                       1015
#define IDC_BUTTON2                     1017
#define IDC_OPENDIR                     1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
